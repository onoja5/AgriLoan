<Button 
  variant="outline-primary"
  size="sm"
  onClick={() => navigate(`/${userRole}/repayment/${loan.id}`)}
>
  Make Payment
</Button>